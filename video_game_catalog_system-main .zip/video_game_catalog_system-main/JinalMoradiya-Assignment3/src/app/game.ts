export class Game {

    name: string;
    system: string;
    genre: string;
    price: number;
    gid: number;


}
