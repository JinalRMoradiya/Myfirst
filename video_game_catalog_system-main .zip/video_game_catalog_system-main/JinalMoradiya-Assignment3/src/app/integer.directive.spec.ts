import { IntegerDirective } from './integer.directive';

describe('IntegerDirective', () => {
  it('should create an instance', () => {
    const directive = new IntegerDirective();
    expect(directive).toBeTruthy();
  });
});
